package com.somegroup.cardfeed.model;

public enum CardType {
	DAILY_QUOTE,
	STATUS_UPDATE;
	
}
