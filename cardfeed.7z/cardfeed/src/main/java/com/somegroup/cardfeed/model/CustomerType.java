package com.somegroup.cardfeed.model;

public enum CustomerType {

	TYPE_A, TYPE_B, TYPE_C;
}
