package com.somegroup.cardfeed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CardfeedApplication {

	public static void main(String[] args) {
		SpringApplication.run(CardfeedApplication.class, args);
	}

}
